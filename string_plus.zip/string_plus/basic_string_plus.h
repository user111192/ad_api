// Copyright (c) 2025. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
// Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
// Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
// Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
// Vestibulum commodo. Ut rhoncus gravida arcu.

//
// Created by 陈子昂 on 2025/5/10.
//

#ifndef BASIC_STRING_PLUS_H
#define BASIC_STRING_PLUS_H
#include <string>
#include <compare>
#include <functional>
using std::string;




// 替换原来的 default_banned_predicate 函数
struct default_banned_predicate {
    inline bool operator()(const string& str) const {
        return false;
    }
};

template<typename isBanned> 
#if __cplusplus >= 202002L
requires std::predicate<isBanned, const string&>
#endif
class basic_string_plus {
    string m_str, alternative="error";

public:

    basic_string_plus();
    basic_string_plus(const string &str);
    basic_string_plus(const char *str);
    basic_string_plus(const basic_string_plus &str);
    basic_string_plus(basic_string_plus&& str) noexcept;
    ~basic_string_plus();

    basic_string_plus &operator=(const basic_string_plus &str);

    basic_string_plus &operator=(basic_string_plus &&str) noexcept;

    string& str();
    const string& strc() const;
    const char* c_str() const;
    explicit operator const string &() const;
    explicit operator const char *() const;

    auto operator<=>(const basic_string_plus &str2) const {
        return m_str <=> str2.m_str;
    }
};

// 使用时无需显式传入模板参数
// using string_plus = basic_string_plus<default_banned_predicate>;


#endif //BASIC_STRING_PLUS_H
