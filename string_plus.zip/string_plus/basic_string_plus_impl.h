// Copyright (c) 2025. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
// Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
// Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
// Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
// Vestibulum commodo. Ut rhoncus gravida arcu.

//
// Created by 陈子昂 on 2025/5/10.
//

#ifndef BS_IMPL
#define BS_IMPL
#include "basic_string_plus.h"


template<typename isBanned> 
#if __cplusplus >= 202002L
requires std::predicate<isBanned, const string&>
#endif
basic_string_plus<isBanned>::basic_string_plus() = default;
template<typename isBanned> 
#if __cplusplus >= 202002L
requires std::predicate<isBanned, const string&>
#endif
basic_string_plus<isBanned>::basic_string_plus(const string &str) {
    m_str = str;
    if (isBanned()(m_str)) {
        m_str = "error";
    }
}
template<typename isBanned> 
#if __cplusplus >= 202002L
requires std::predicate<isBanned, const string&>
#endif
basic_string_plus<isBanned>::basic_string_plus(const basic_string_plus &str) {
    m_str = str.m_str;
    if (isBanned()(m_str)) {
        m_str = "error";
    }
}
template<typename isBanned> 
#if __cplusplus >= 202002L
requires std::predicate<isBanned, const string&>
#endif
basic_string_plus<isBanned>::basic_string_plus(const char *str) {
    m_str = str;
    if (isBanned()(m_str)) {
        m_str = "error";
    }
}

template<typename isBanned> 
#if __cplusplus >= 202002L
requires std::predicate<isBanned, const string&>
#endif
basic_string_plus<isBanned>::basic_string_plus(basic_string_plus &&str) noexcept {
    m_str = std::move(str.m_str);
    if (isBanned()(m_str)) {
        m_str = "error";
    }
}

template<typename isBanned> 
#if __cplusplus >= 202002L
requires std::predicate<isBanned, const string&>
#endif
basic_string_plus<isBanned>::~basic_string_plus() {
    m_str.clear();
}

template<typename isBanned> 
#if __cplusplus >= 202002L
requires std::predicate<isBanned, const string&>
#endif
basic_string_plus<isBanned> &basic_string_plus<isBanned>::operator=(const basic_string_plus &str) {
    m_str = str.m_str;
    if (isBanned()(m_str)) {
        m_str = "error";
    }
    return *this;
}

template<typename isBanned> 
#if __cplusplus >= 202002L
requires std::predicate<isBanned, const string&>
#endif
basic_string_plus<isBanned> &basic_string_plus<isBanned>::operator=(basic_string_plus &&str) noexcept {
    m_str = std::move(str.m_str);
    if (isBanned()(m_str)) {
        m_str = "error";
    }
    return *this;
}

template<typename isBanned> 
#if __cplusplus >= 202002L
requires std::predicate<isBanned, const string&>
#endif
string &basic_string_plus<isBanned>::str() {
    if (isBanned()(m_str)) {
        m_str = "error";
    }
    return m_str;
}

template<typename isBanned> 
#if __cplusplus >= 202002L
requires std::predicate<isBanned, const string&>
#endif
const string &basic_string_plus<isBanned>::strc() const {
    if (isBanned()(m_str)) {
        return alternative;
    }
    return m_str;
}

template<typename isBanned> 
#if __cplusplus >= 202002L
requires std::predicate<isBanned, const string&>
#endif
const char *basic_string_plus<isBanned>::c_str() const {
    if (isBanned()(m_str)) {
        return alternative.c_str();
    }
    return m_str.c_str();
}


template<typename isBanned> 
#if __cplusplus >= 202002L
requires std::predicate<isBanned, const string&>
#endif
basic_string_plus<isBanned>::operator const string&() const {
    if (isBanned()(m_str)) {
        return alternative;
    }
    return m_str;
}


template<typename isBanned> 
#if __cplusplus >= 202002L
requires std::predicate<isBanned, const string&>
#endif
basic_string_plus<isBanned>::operator const char*() const {
    if (isBanned()(m_str)) {
        return alternative.c_str();
    }
    return m_str.c_str();
}

#endif