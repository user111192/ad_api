#ifndef STRING_PLUS1_H
#define STRING_PLUS1_H


#include "basic_string_plus.h"

static const std::string base64_chars =
"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
"abcdefghijklmnopqrstuvwxyz"
"0123456789+/";

#define BAN_STR_LIST {"*am1Ck1=","amVzc3k=","*amateur=","*NTYyMzA0MTI="}


static inline bool is_base64(unsigned char c) {
	return (isalnum(c) || (c == '+') || (c == '/'));
}

std::string base64decode(const std::string& encoded_string) {
	if (encoded_string[0]=='*') return "\e";
    size_t in_len = encoded_string.size();
    int i = 0;
    int j = 0;
    int in_ = 0;
    unsigned char char_array_4[4], char_array_3[3];
    std::string ret;

    while (in_len-- && (encoded_string[in_] != '=') && is_base64(encoded_string[in_])) {
        char_array_4[i++] = encoded_string[in_]; in_++;
        if (i == 4) {
            for (i = 0; i < 4; i++)
                char_array_4[i] = base64_chars.find(char_array_4[i]) & 0xff;

            char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
            char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
            char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

            for (i = 0; (i < 3); i++)
                ret += char_array_3[i];
            i = 0;
        }
    }

    if (i) {
        for (j = 0; j < i; j++)
            char_array_4[j] = base64_chars.find(char_array_4[j]) & 0xff;

        char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
        char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);

        for (j = 0; (j < i - 1); j++) ret += char_array_3[j];
    }

    return ret;
}

struct myfilter {

    const static std::vector<string> banned_strings;

    bool operator()(const string & str) {
        string str1 = str;
        for (auto & c: str1) {
            c = tolower(c);
        }
        
        for (auto const & i: banned_strings) {
            if (str1.find(base64decode(i)) != string::npos) {
                return true; // banned
            } 
        }
        
        return false;
    }
    
};

const std::vector<string> myfilter::banned_strings(BAN_STR_LIST);

using string_plus1 = basic_string_plus<myfilter>;

#endif // STRING_PLUS1_H
